<html>
    <head>
        <style>
          .di{border: 1px solid white; height: 200px; background-color: rgba(245, 228, 228, 0.57);}
          .lo{width: 200px;height:200px;position:relative;right: -370px;}
          .name{ color: palevioletred;font-family: cursive;font-size: 50px;position: relative;text-align:center;top: -194px;}
          ul,li{ list-style-type: none;}
           li{ border: 1px solid white;float: left;padding: 10px;font-size: 20px; position: relative;right: -450px;}
           .a1{color: purple;text-decoration: none;}
           .a1:hover{ color: red;}
           .ah{color: palevioletred;position: relative;top: 72px;right: -200px;}
           .ap{position: relative;top: 73px;right: -330px;}
           .app{position: relative;top: 73px;right: -470px;}
           .footer{border: 1px solid black;background-color: black;position: relative;top: 130px;right:-200px;width: 800px;height: 80px;border-radius: 50px;}
           .fh{color: palevioletred;font-family: cursive;padding: 20px;position: relative;top: -25px;}
           .fp1{color: white;position: relative;right: -483px;top: -109px;}
           .fp2{color: white;position: relative;right: -460px;top: -110px;}
           .dav2{border: 1px solid white;width: 1000px;position: relative;top: 108px;height: 500px;right: -168px;}
           .dav2a{border: 1px solid white;height: 200px;width: 250px;position: relative;right: -97px;}
           .ia1{height: 70px;width: 70px;border-radius: 50px;position:relative;right: -85px;}
           .ha1{text-align: center;}
           .paa{padding: 20px;}
           .dav2b{border: 1px solid white;height: 200px;width: 250px;position: relative;right: -365px;top: -202px;}
           .ia2{height: 70px;width: 70px;border-radius: 50px;position: relative;right: -85px;}
           .ha2{text-align: center;}
           .pab{padding: 20px;}
           .dav2c{border: 1px solid white;height: 200px;width: 250px;position: relative;top: -404px;right: -630px;}
           .ia3{height: 70px;width: 70px;border-radius: 50px;position: relative;right: -85px;}
           .ha3{text-align: center;}
           .pac{padding: 20px;}
           .dav2d{border: 1px solid white;height: 200px;width: 250px;position: relative;top: -389px;right: -232px;}
           .ia4{height: 70px;width: 70px;border-radius: 50px;position: relative;right: -85px;}
           .ha4{text-align: center;}
           .pad{padding: 20px;}
           .dav2e{border: 1px solid white;height: 200px;width: 250px;position: relative;top: -591px;right: -503px;}
           .ia5{height: 70px;width: 70px;border-radius: 50px;position: relative;right: -85px;}
           .ha5{text-align: center;}
           .pae{padding: 20px;}

        </style>
    </head>
    <body>
        <div class="di">
            <img class="lo" src="images\logo2.jpg" alt="">
            <h1 class="name">Eventia</h1> 
    </div>
     <ul>
            <li><a class="a1" href="page.php">Home</a></li>
            <li><a  class="a1" href="#">About Us</a></li>
            <li><a  class="a1" href="contact.php">Contact Us</a></li>
        </ul>
        <h1 class="ah">About Eventia</h1>
        <p class="ap">We specialize in styling big events. If you are looking to celebrate a Reception, Birthday, Official party </p>
        <p class="app">or Anniversary- we offer the perfect solutions to fit your needs. </p>
        <div class="dav2">
             <div class="dav2a">
                 <img class="ia1" src="images\passionate.jpg" alt="">
                 <h2 class="ha1">Passionate</h2>
                 <p class="paa">We are just mad at everything about celebrations!</p>
             </div>
             <div class="dav2b">
                <img class="ia2" src="images\pinkglobe.jpg" alt="">
                <h2 class="ha2">Responsible</h2>
                <p class="pab">We are bigger than our defined roles.</p>
            </div>
            <div class="dav2c">
                <img class="ia3" src="images\hammer.jpg" alt="">
                <h2 class="ha3">Impact</h2>
                <p class="pac">We are born to make impact</p>
            </div>
            <div class="dav2d">
                <img class="ia4" src="images\tick.jpg" alt="">
                <h2 class="ha4">Get things done</h2>
                <p class="pad">well, we believe actions speaks beyond words. and we live it.</p>
            </div>
            <div class="dav2e">
                <img class="ia5" src="images\cap.jpg" alt="">
                <h2 class="ha5">Fun</h2>
                <p class="pae">Our tiniest success to biggest failure, we celebrate alike.</p>
            </div>
            
        </div>
        <div class="Footer">
            <h1 class="fh">Eventesia</h1>
            <p class="fp1">@2018 eventesia. All rights reserved.</p>
            <p class="fp2">Designed and developed by Rushitha</p>
        </div>
    </body>
</html>