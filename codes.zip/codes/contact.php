<html>
    <head>
        <style>
        .di{border: 1px solid white; height: 200px; background-color: rgba(245, 228, 228, 0.57);}
          .lo{width: 200px;height:200px;position:relative;right: -370px;}
          .name{ color: palevioletred;font-family: cursive;font-size: 50px;position: relative;text-align:center;top: -194px;}
          ul,li{ list-style-type: none;}
           li{ border: 1px solid white;float: left;padding: 10px;font-size: 20px; position: relative;right: -450px;}
           .a1{color: purple;text-decoration: none;}
           .a1:hover{ color: red;}
           .footer{border: 1px solid black;background-color: black;position: relative;top: 130px;right:-200px;width: 800px;height: 80px;border-radius: 50px;}
           .fh{color: palevioletred;font-family: cursive;padding: 20px;position: relative;top: -25px;right:-1px;}
           .fp1{color: white;position: relative;right: -483px;top: -109px;}
           .fp2{color: white;position: relative;right: -460px;top: -110px;}
           .cdiv{border: 1px solid white; width: 500px;position: relative;right: -373px;top: 76px;background: linear-gradient(pink,purple)}
           .ch{text-align: center;position:relative;right:148px;color:purple;}
           .contp{padding: 20px;font-size: 20px;}
           .ap1{padding: 20px;position:relative;top: -45px;font-size: 20px}
           .ap2{padding: 20px;position:relative;top: -80px;font-size: 20px;}
     </style>
    </head>
    <body>
        <div class="di">
            <img class="lo" src="images\logo2.jpg" alt="">
            <h1 class="name">Eventia</h1> 
    </div>
     <ul>
            <li><a class="a1" href="page.php">Home</a></li>
            <li><a  class="a1" href="about.php">About Us</a></li>
            <li><a  class="a1" href="#">Contact Us</a></li>
        </ul>
        <img src="images\capture.png" alt="">
        <div class="cdiv">
            <h2 class="ch">Wanna chat?</h2>
            <p class="contp">For further inquiries regarding the design, price, collaborations please email us here </p>
            <p class="ap1">enventia@gmail.com</p>
            <p class="ap2">Or ping us on - 9686337914 | 080-23479219 </p>
        </div>
        <div class="Footer">
            <h1 class="fh">Eventia</h1>
            <p class="fp1">@2018 eventesia. All rights reserved.</p>
            <p class="fp2">Designed and developed by Rushitha</p>
        </div>
    </body>
</html>