
<html>
    <head>
        <style>
            
          .div1{border: 1px solid white; height: 200px; background-color: rgba(245, 228, 228, 0.57);}
          .logo{width: 200px;height:200px;position:relative;right: -365px;}
            .name{ color: palevioletred;font-family: cursive;font-size: 50px;position: relative;text-align:center;top: -194px;}
          #ab{position: relative;top: -200px;right: -770px;}
          #cd{ position: relative;top: -247px;right: -1165px;}
          #aa{color:#E03A74; text-decoration: none;}
           #bb{ color: #690869;text-decoration: none; }
           #xy{color: white;font-family:cursive; text-align: center;}
           #div3{border: 1px solid rgba(233, 219, 219, 0.79);width: 1000px;position: relative; right: -116px;height: 400px; padding: 20px; background-color: rgba(233, 219, 219, 0.79);top: 40px;}
           .divh2{ text-align: center;}
           .divp{font-size: 20px;text-align: center;color: red; }
           #div3a{border: 1px solid white;width: 300px;position: relative;top: 2px;right: -48px}
           .ha{text-align: center;color:red; }
           .pa{padding: 20px; }
           .hb{text-decoration: underline;color: gray; position: relative;right: -264px;}
           #div3b{border: 1px solid white;width: 300px;height: 227.625;position: relative;top: -228px;right: -351px; background-color: black; }
           .hc{color: white;text-align: center;color: red; }
           .pb{ padding: 20px; color: white;}
           .hd{text-decoration: underline; color: gray;position: relative;right: -264px;}
           #div3c{border: 1px solid white;width: 300px;height: 227.625;position: relative;top: -458px;right: -654px;}
           .he{text-align: center;color: red;}
           .pc{padding: 20px;}
           .hf{text-decoration: underline;color: gray;position: relative; right: -264px; top: -18px }
           .div4{ border: 1px solid white; width:1400px; height: 400px; position: relative;top: 93px; background-color: rgba(233, 219, 219, 0.79);}
           .head{ text-align: center;position: relative;right: 50px;}
           .div4a{ border: 1px solid rgba(233, 219, 219, 0.79); width: 250px; height: 250px; position: relative; right: -125px;}
           .image1{height: 50px;width: 50px;position: relative; top: 9px;right: -96px;}
           .h1{text-align: center; color: red;}
           .p1{padding: 20px; position: relative;top: -30px; }
           .div4b{ border: 1px solid rgba(233, 219, 219, 0.79); width: 250px; height: 250px;position: relative; right: -384px; top: -252px; }
           .image2{ height: 50px; width: 50px; position: relative;top: 9px; right: -96px; }
           .h2{ text-align: center;color: red;}
           .p2{ padding: 20px; position: relative;top: -30px; }
           .div4c{ border: 1px solid rgba(233, 219, 219, 0.79);width: 250px; height: 250px; position: relative; top: -503px;right: -644px;}
           .image3{ height: 50px; width: 50px; position: relative;top: 9px; right: -96px; }
           .h3{ text-align: center; color: red; }
           .p3{ padding: 20px; position: relative; top: -30px; }
           .div4d{ border: 1px solid rgba(233, 219, 219, 0.79); width: 250px; height: 250px;position: relative;top: -755px;right: -901px;}
           .image4{ height: 70px; width: 70px; position: relative;top: 0px;right: -96px;}
           .h4{text-align: center; position: relative; top: -21px;color: red;}
           .p4{ padding: 20px; position: relative; top: -49px;}
           ul,li{ list-style-type: none;}
           li{ border: 1px solid white;float: left;padding: 10px;font-size: 20px; position: relative;right: -450px;}
           .a1{color: purple;text-decoration: none;}
           .a1:hover{ color: red;}
           .show{height:300px;width: 400px;padding: 20px;}
           .headshow{text-align: center;color: palevioletred;}
           .textshow{text-align: center;color: purple;}
           .showdiv{position: relative;right: -182px;}
           .footer{border: 1px solid black;background-color: black;position: relative;top: 130px;right:-200px;width: 800px;height: 80px;border-radius: 50px;}
           .fh{color: palevioletred;font-family: cursive;padding: 20px;position: relative;top: -25px;}
           .fp1{color: white;position: relative;right: -483px;top: -109px;}
           .fp2{color: white;position: relative;right: -460px;top: -110px;}
           .back{color:black;position:relative;top: 76px;right: -1024px;}
        </style>
    </head>
    <body>
        <div class="div1">
                <img class="logo" src="images\logo2.jpg" alt="">
                <h1 class="name">Eventia</h1> 
        </div>
         <ul>
                <li><a class="a1" href="#">Home</a></li>
                <li><a  class="a1" href="about.php">About Us</a></li>
                <li><a  class="a1" href="contact.php">Contact Us</a></li>
            </ul>
            <h2 id=ab><a id=aa href="login.php">LogIn</a></h2>
            <h2 id=cd><a id=bb href="signup.php">SignUp</a></h2>
           
                <h1 class="headshow">Planning for a party..??</h1>
                <h2 class="textshow">Here are some amazing designs!!!</h2>
                <div class="showdiv">
                <img class="show" src="images\3b.jpg" alt="">
                <img class="show"  src="images\3h.jpg" alt="">
                <img class="show" src="images\4b.jpg" alt="">
                <img class="show" src="images\j.jpg" alt="">
                <img class="show" src="images\put.jpg" alt="">
                <img class="show"  src="images\2e.jpg" alt=""></div>
        <div id=div3>
            <h2 class="divh2">How it works..???</h2>
            <p class="divp">Here is the better way to plan your party!!</p>
            <div id=div3a>
                 <h2 class="ha"> Browse</h2>
                <p class="pa">Checkout our 1,000+ range of offerings with best designs with accurate pricing, details, real pictures and reviews</p>
                <h2 class="hb">1</h2>
            </div>
            <div id=div3b>
                <h2 class="hc">Finalize</h2>
                <p class="pb">Our expert party planning team will help you with any custamization or clarifications to finalize your order</p>
                <h2 class="hd">2</h2>
            </div>
            <div id=div3c>
                <h2 class="he">Book</h2>
                <p class="pc">Block your slot securely by paying an advance of 30% of booking amount. Sit back relax and enjoy your party as rest is taken care of</p>
                <h2 class="hf">3</h2>
            </div>
        </div>
        <div class="div4">
            <h2 class="head">Why choose EVENTIA..??</h2>
            <div class="div4a">
                    <img  class="image1" src="images\deal.png" alt="">
                    <h2 class="h1">Best Deals</h2>
                    <p class="p1">Explore best party services along with latest trends happening around the city instantly. Get the benefit of pre-negotiated prices without bargaining</p>
    </div>
            <div class="div4b">
                <img class="image2" src="images\kart.png" alt="">
                <h2 class="h2">Online Booking</h2>
                <p class="p2">You can choose and finish your party planning within minutes depending on your preferences at your own convinience with secure online payments</p>
            </div>
            <div class="div4c">
                <img class="image3" src="images\badge.jpg" alt="">
                <h2 class="h3">100% Service</h2>
                <p class="p3">Be assured of 100% ontime quality service delivery from our experienced and verified partners</p>
            </div>
            <div class="div4d">
                <img class="image4" src="images\customer.jpg" alt="">
                <h2 class="h4">2,000+ Happy Guests</h2>
                <p class="p4">Over 500+ parties have been powered by EVENTIA. Many people like you have made their party planning simple & effortless  </p>
            </div>
        </div>
        <div class="Footer">
            <h1 class="fh">Eventia</h1>
            <p class="fp1">@2018 eventesia. All rights reserved.</p>
            <p class="fp2">Designed and developed by Rushitha</p>
        </div>
        <a class="back" href="page.php"> <b>Back to top</b> </a>
        </body>
</html>


