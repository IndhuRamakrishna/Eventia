
<html>
    <head>
      <style>
           @font-face{
        font-family:tan;
        src:url(satisfy-regular.ttf);
    }
        .img1{
            position: relative;
            height: 600px;
            width: 800px;
            right: -249px;
        }
        .img2{
            position: relative;
            height: 800px;
            width: 800px;
            right: -249px;
        }
        .head{
            position: relative;
            text-align: center;
            font-family: tan;
            color: goldenrod;
        }
        .head2{
            position: relative;
            text-align: center;
            font-family: tan;
            color: goldenrod;
        }
        .head3{
            position: relative;
            text-align: center;
            font-family: tan;
            color: purple;
            font-size: 30px;
        }
        .head4{
            position: relative;
            text-align: center;
            font-size: 20px;
        }
        .head5{
            border:1px solid pink;
            background-color: pink;
            height: 75px;
            width: 500px;
            position: relative;
            font-size: 25px;
            font-family: tan;
            border-radius: 25px;
        }
        
        div{
            position: relative;
            right: -370px;
        }
        a{
            text-decoration:none;
            color:purple;
            position:relative;
            top:24px;
            right:-213px;
        }
      </style>
    </head>
    <body>
            <h2 class="head3">Silver Ball</h2>
        <img class="img1" src="hall\o4.jpg" alt="">
        <h1 class="head">Design</h1>
        
       
        <p class="head4"><b>Price:15,000</b></p>
        <div class="head5"> 
        <a href="v11.php">Select</a>
        
        </div>
       
        <!-- <div class="head5"><h2 > <b>Select</b> </h2></div>
        <div class="head6"><h2 > <b>Delete</b> </h2></div> -->
    </body>
</html>